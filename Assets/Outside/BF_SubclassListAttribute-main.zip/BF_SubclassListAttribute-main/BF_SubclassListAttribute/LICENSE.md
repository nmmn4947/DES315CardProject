Do not re-use in assets/plugins/packages without express permission.
Do not redistribute.

Use in games.